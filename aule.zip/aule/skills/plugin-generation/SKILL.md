---
name: plugin-generation
description: >
  Use this skill after completing plugin discovery, when you need to "generate the plugin",
  "create the plugin files", "build out the plugin", "produce the plugin", "write the plugin code",
  "generate plugin from discovery", "make the plugin from our plan", or "turn this into a plugin".
  Takes the discovery summary and produces a complete, ready-to-use plugin following Olytic conventions.
  Every generated plugin automatically includes telemetry, integrity controls, permissions manifest,
  and documentation. See references/ for templates and patterns.
version: 0.2.0
---

# Plugin Generation

Take a completed discovery summary and generate a complete plugin. Follow every rule in this skill exactly — these are Olytic's hard-coded standards for plugin quality.

## Agentic Best Practices (Mandatory)

Every generated plugin must comply with these protocols. See `references/agentic-best-practices.md` for full details.

**Core Protocols — embed in every generated skill, agent, and command:**
- **Discovery first:** Before acting, map the existing environment. Use search/glob to understand what exists. Never recreate existing files or structures.
- **Source of truth:** Local files (skill content, references, JSON) take precedence over conversational context. If conflict exists, the file wins.
- **Atomic operations:** Make the smallest change necessary. Use targeted edits, not full-file rewrites. Minimum API calls.
- **No redundancy:** Reference files instead of repeating their content. Use "Reference: [filename]" patterns. If knowledge exists in The One Ring, point to it — don't copy it.

**Tool & Token Management — embed in agents and commands:**
- **Search over read:** Use Grep/Glob to target specific data. Never read files >50KB in their entirety if specific information can be targeted.
- **Programmatic processing:** For data-heavy tasks, write a processing script and return only the result — don't load raw data into context.
- **Batching:** Consolidate related operations into single turns. Read multiple files in parallel, not sequentially.

**Data Governance — embed in all components:**
- **Metadata integrity:** Every automated entry (logs, commits, generated content) must include a timestamp and source tag.
- **Active workspace vs cold storage:** Telemetry logs are write-only during normal operation. Only access them when the user explicitly asks for history.

**Safety & Quality Guardrails — embed in every command and agent:**
- **Verification gate:** Every write operation must be followed by a verification check. Confirm file structure is valid after writes.
- **No hallucination:** If a variable, file path, or data point is not found, report "Not Found" immediately. Never guess or estimate.
- **Permission gate:** Ask for confirmation before destructive actions (delete, overwrite) or 5+ simultaneous file changes.

## Generation Process

### Step 0: Discovery First — Map the Environment

Before generating anything:
1. Check if a plugin with this name already exists in the working directory (use Glob)
2. Check if a marketplace entry already exists (use the marketplace-management skill)
3. If the plugin exists, ask: "A plugin named [name] already exists. Do you want to update it or create a new one?"
4. If not, proceed to Step 1

### Step 1: Determine Components

Map discovery answers to component types:

| Discovery Signal | Component Type | Reasoning |
|-----------------|----------------|----------|
| Key functions that involve **knowledge or standards** | Skill | User needs domain expertise loaded into context |
| Key functions that involve **repeatable actions** | Command | User needs a `/slash-command` entry point |
| Key functions that involve **multi-step reasoning or orchestration** | Agent | User needs an autonomous workflow |
| External integrations selected | .mcp.json | Plugin needs MCP server connections |
| Strategic questions defined | Embedded in skills and agents | Guide decision-making within components |
| Constraints defined | Embedded in skills + telemetry | Enforced as guardrails and tracked as violations |
| Success metrics + data sources | Performance command (if data source is accessible) | Enable self-measurement |
| Memory scope declared (from Q5) | Memory declaration in skill + README | Plugin declares its context retention requirements |
| Workflow context mapped (from Q6) | Augmentation framing in README + skill descriptions | Positions plugin around new capabilities, not just task speedup |
| Augmentation signal weak | Advisory note in README | Flags the plugin as primarily an accelerator, suggests augmentation opportunities |
| Claude OS framing (from new questions) | Claude OS Identity block in README | Declares hat role, relationships, governance, dimension, compounding |

**Rules:**
- Every plugin gets at least ONE skill (the primary domain skill)
- Every plugin gets the telemetry skill (non-negotiable — see `references/telemetry-template.md`)
- Only create agents if the workflow genuinely requires multi-step orchestration
- Only create commands if there's a clear, repeatable user-initiated action
- Create a performance/metrics command if at least one data source from Q8 is programmatically accessible
- Every plugin must include a Claude OS Identity block in its README (see Step 4b below)

### Step 2: Name Components

Follow Olytic naming conventions from `references/olytic-patterns.md`:

- **Plugin name:** kebab-case, 2-4 words, descriptive (e.g., `customer-success-tracker`)
- **Skills:** `[domain]-[function]` (e.g., `proposal-standards`, `deal-qualification`)
- **Commands:** `[verb]-[object]` (e.g., `pull-metrics`, `score-health`, `review-proposal`)
- **Agents:** `[role]-[responsibility]` (e.g., `deal-analyst`, `proposal-reviewer`)

### Step 2a: Validate Component Name Uniqueness

Before proceeding to file generation, check that **no two components share the same name** across skills, commands, and agents. Skills, commands, and agents share the same qualified namespace (`plugin-name:component-name`), so names must be unique across all three types within a plugin.

Collect all planned names:
- Skill directory names (e.g., `proposal-standards`)
- Command file names without `.md` (e.g., `review-proposal`)
- Agent file names without `.md` (e.g., `proposal-reviewer`)

If any duplicates exist, rename the component with the weaker claim to the name:
- **Skills** (knowledge/standards) should add a suffix like `-standards`, `-guide`, or `-framework`
- **Commands** (actions) keep the verb-object name since users invoke them directly
- **Agents** (roles) keep the role-responsibility name

**This check is non-negotiable.** A duplicate will cause the plugin to register the same qualified name for two different components, creating unpredictable behavior.

### Step 3: Generate Plugin Structure

Create this directory structure:

```
[plugin-name]/
├── .claude-plugin/
│   └── plugin.json
├── .mcp.json                    # Only if integrations exist
├── README.md
├── skills/
│   ├── plugin-telemetry/        # ALWAYS included — non-negotiable
│   │   └── SKILL.md
│   └── [domain-skill]/
│       ├── SKILL.md
│       └── references/          # Only if domain needs detailed reference material
│           └── [reference].md
├── agents/                      # Only if agents are needed
│   └── [agent-name].md
└── commands/                    # Only if commands are needed
    └── [command-name].md
```

### Step 4: Generate Each File

#### plugin.json

Write to `.claude-plugin/plugin.json`. Use ONLY these keys — no others:

```json
{
  "name": "[kebab-case-name]",
  "version": "0.1.0",
  "description": "[plugin_purpose from discovery — one sentence, under 120 chars]",
  "author": {
    "name": "[Olytic Solutions for internal, client name for client plugins]",
    "email": "[support@olyticsolutions.com for internal, client email for client plugins]"
  },
  "keywords": ["keyword1", "keyword2", "keyword3"],
  "sublabel": "[1–3 words describing what the plugin does — unique across the catalog]",
  "icon": "[single emoji — thematically relevant, unique across the catalog]"
}
```

**⚠️ Valid keys only:** `name`, `version`, `description`, `author`, `keywords`, `hooks`, `sublabel`, `icon`. Do NOT include `displayName` or any other key — unrecognized keys cause upload failure. Keywords must be an array of plain strings, not a single placeholder string.

**⚠️ Sublabel:** 1–3 words, title case, describes what the plugin *does*. Must be unique across the Olytic plugin catalog. Check `references/olytic-patterns.md` for current catalog values before assigning.

**⚠️ Icon:** Single emoji character, thematically relevant to the plugin's function. Must be unique across the Olytic plugin catalog. Check `references/olytic-patterns.md` for current catalog values before assigning.

**Immediately after writing plugin.json**, run this validation bash command to confirm the file was written correctly. Do NOT proceed until this passes:

```bash
python3 -c "
import json, sys
try:
    with open('.claude-plugin/plugin.json') as f:
        content = f.read()
    if not content.strip():
        print('FAIL: plugin.json is empty — rewrite the file')
        sys.exit(1)
    data = json.loads(content)
    valid_keys = {'name','version','description','author','keywords','hooks','sublabel','icon'}
    bad_keys = [k for k in data if k not in valid_keys]
    missing = [k for k in ['name','version','description','author'] if k not in data]
    if bad_keys:
        print('FAIL: unrecognized keys:', bad_keys)
        sys.exit(1)
    if missing:
        print('FAIL: missing required fields:', missing)
        sys.exit(1)
    print('OK — plugin.json is valid')
    print(json.dumps(data, indent=2))
except json.JSONDecodeError as e:
    print('FAIL: invalid JSON —', e)
    sys.exit(1)
except FileNotFoundError:
    print('FAIL: .claude-plugin/plugin.json not found — check the write path')
    sys.exit(1)
"
```

If this script exits with an error, fix the file and re-run before continuing.

#### .mcp.json (only if integrations exist)

Generate MCP server entries for each integration from discovery Q5. Common patterns:

```json
{
  "mcpServers": {
    "github": {
      "type": "http",
      "url": "https://api.githubcopilot.com/mcp/"
    }
  }
}
```

For integrations without a known MCP server URL, add a comment in README noting the integration needs configuration.

#### Telemetry Skill

**This is mandatory for every generated plugin.** Copy and customize from `references/telemetry-template.md`. Replace:
- `[PLUGIN_NAME]` → actual plugin name
- `[PLUGIN_VERSION]` → "0.1.0"
- `[CONSTRAINTS]` → constraints from discovery Q4
- `[SUCCESS_METRICS]` → metrics from discovery Q8

#### Domain Skills

For each domain skill, generate using the pattern from `references/component-templates.md`. Key rules:

- **Frontmatter description** must include 4-6 specific trigger phrases in the user's language
- **Body** starts with a context paragraph explaining scope
- **Strategic questions** from Q3 are embedded as a "Before You Start" or "Decision Framework" section
- **Constraints** from Q4 are embedded as a "Boundaries" or "Out of Scope" section
- **Memory scope** (from Q5): If the skill requires context persistence or retrieval, include a Memory Scope section declaring what information must be retained across sessions and for how long. If discovery Q5 indicates 'retrieval' memory scope, include retrieval configuration in the skill: what sources to search, freshness requirements, and fallback behavior when sources are unavailable.
- **Content processing security** (from Q7): If the plugin processes external content (user uploads, web data, third-party API responses), include prompt injection defense patterns: input validation, output filtering, and clear boundaries between trusted instructions and untrusted data.
- **Operating Principles** section must be included (from `references/agentic-best-practices.md`):
  - Discovery first: Assess current state before taking action
  - Source of truth: Local files and skill content take precedence over conversation
  - Atomic operations: Make the smallest change necessary
  - Verify after writing: Confirm output is valid after every write operation
  - No hallucination: Report "Not Found" rather than guessing
- **Structure** uses H2 sections, bullets, tables, bold key terms (Olytic voice)
- If the skill needs detailed reference material, create `references/` files

#### Agents

For each agent, generate using the pattern from `references/component-templates.md`. Key rules:

- **Frontmatter YAML structure (critical):** The `---` frontmatter block must contain ONLY valid YAML key-value pairs: `name`, `description`, `model`, `color`, `tools`. The `<example>` blocks are NOT valid YAML and must be placed AFTER the closing `---`, not inside it. Placing examples inside the frontmatter causes a YAML parse error that breaks plugin upload.
- **Agent description format (critical):** Always write agent descriptions using the `description: >` block scalar format. Never use a single-line unquoted description. A single-line description containing `: ` (colon + space) will cause a "mapping values are not allowed here" YAML parse error on upload.
- **Color assignment:** Pick from yellow, magenta, cyan, green, orange — no two agents in the same plugin share a color
- **Tools list** should match what the agent actually needs (Read, Write, Grep, Glob, WebSearch, WebFetch, plus any MCP tools from integrations)
- **Body** includes: role description, core responsibilities (3-6 bullets), analysis process (numbered steps), output format (exact template)
- **Strategic questions** from Q3 inform the agent's decision-making logic
- **Agentic rules section** must be included in every agent body:
  - Map environment before acting — use search/glob to understand what exists
  - Treat skill content as authoritative over conversational context
  - Batch related operations to minimize token overhead
  - Use targeted search over full-file reads for large files
  - Verify every write operation succeeded
  - Never fabricate data — report missing information explicitly
  - Confirm with user before destructive actions or 5+ file changes

#### Commands

For each command, generate using the pattern from `references/component-templates.md`. Key rules:

- **Frontmatter** includes `description` (one line), `argument-hint` (example usage), `allowed-tools` (specific tool list)
- **Body** is instructions FOR Claude, not documentation for the user
- **Steps** are numbered, specific, and include confirmation before destructive actions
- **Integration-specific tools** reference MCP servers by full name (e.g., `mcp__github__get_file_contents`)
- **Verification gate:** Every command that writes files or modifies external systems must include a verification step after the write to confirm success
- **Permission gate:** Commands that perform destructive actions or make 5+ simultaneous changes must ask for user confirmation
- **No hallucination:** Commands must report "Not Found" for missing files/data rather than guessing

### Step 4a: Generate Permissions Manifest

**This is mandatory for every generated plugin.** Create a new section in the README (see Step 4b's README.md template below).

The permissions manifest is a structured declaration of:

- **Tools accessed:** Which Claude tools does the plugin use? (Read, Write, Grep, Glob, WebSearch, WebFetch, etc.)
- **MCP servers:** What external systems does it connect to? (GitHub, Slack, databases, APIs, etc.)
- **Data reads:** What data sources does the plugin read from? (local files, APIs, databases, user uploads)
- **Data writes:** What does it write to? (files, external APIs, logs, caches)
- **External services called:** Third-party APIs, webhooks, or cloud services
- **Human-in-the-loop checkpoints:** Which operations require user confirmation before execution? (destructive actions, payments, access grants, data transmission)

Example structure:

```markdown
## Permissions Manifest

### Tools
- Read: Local filesystem access
- Write: Skill and command file creation
- Grep: Code searching
- Glob: Directory traversal
- WebFetch: External documentation fetching

### Integrations
- GitHub API: Read repository contents, create issues

### Data Access
**Reads:** Repository files, issue metadata
**Writes:** Local skill cache, telemetry logs
**Retention:** Telemetry logs stored for 90 days

### Human-in-the-Loop Checkpoints
- ✓ Required before creating issues
- ✓ Required before modifying repository permissions
- ✓ Required before sharing analysis results externally
```

### Step 4b: Generate Claude OS Identity Block

**This is mandatory for every generated plugin.** Create a new section in the README called **Claude OS Identity** that appears early in the document, after the opening description and before Components.

Populate this block using answers from the Claude OS Framing Questions in discovery:

```markdown
## Claude OS Identity

**Hat:** [Plugin Name] is the [role] hat in the Claude OS — the platonic ideal of [job-to-be-done description from hat_identity].

**Dimension:** This plugin primarily serves the [Unified / Custom / Augmenting / Agentic / Compounding] dimension of the Claude OS. [Brief statement of why: does it help plugins work together, enable personalization, create new capabilities, leverage advanced reasoning, or feed the improvement loop?]

**Governance dependency:** [This plugin assumes The One Ring is installed / This plugin works standalone / Other]. [List which skills it references: e.g., "Uses The One Ring's olytic-brand-standards skill for voice and positioning rules."]

**Relationships to other hats:**
- [Plugin A]: [How this plugin uses or feeds Plugin A — e.g., "proposal-builder feeds completed proposals to proposal-auditor for review"]
- [Plugin B]: [How this plugin interacts]

**Compounding contribution:** [What telemetry does this plugin log that feeds the Optimizer? e.g., "Logs every audit result, constraint violation, and user feedback signal. The Optimizer watches violation patterns to recommend improvements to both proposal-builder and brand standards."]
```

Use the discovery answers to populate each field. If a field wasn't answered (e.g., no other plugins exist yet), note it explicitly (e.g., "No other hats yet" or "Governance dependency: This standalone client plugin does not reference The One Ring").

#### README.md

Generate from discovery data:

```markdown
# [Plugin Name]

Enables [user] to [new capability] — [one paragraph describing what makes this augmentation valuable, not just what it automates].

**Audience:** [user_profile]
**Requires:** [dependencies — e.g., "The One Ring governance plugin" if Olytic internal]

## Claude OS Identity

[See Step 4b — mandatory block declaring hat role, dimension, governance, relationships, and compounding contribution]

## Components

### Skills
- **[skill-name]** — [description]
- **plugin-telemetry** — Automatic usage logging, version tagging, violation tracking, and feedback capture

### Commands
- `/[command-name] [args]` — [description]

### Agents
- **[agent-name]** — [description]

### Integrations
- **[Service]** — [what it connects to and why]

## Strategic Questions

When using this plugin, always consider:
[strategic_questions as numbered list]

## Boundaries

This plugin should NOT be used for:
[constraints as bullet list]

## Memory Scope

This plugin [retains/does not retain] context across sessions:
- [What information is retained]
- [Retention period or conditions]
- [How to clear retained context if needed]

## Permissions Manifest

[See Step 4a — structured declaration of tools, integrations, data access, and human-in-the-loop checkpoints]

## Success Metrics

| Metric | Data Source | How to Measure |
|--------|-----------|----------------|
| [metric] | [source] | [method] |

## Installation

[Installation command — marketplace for Olytic internal, manual for client]

## Customization

[Which files to edit for different changes]
```

### Step 5: Review Generated Structure

Before writing files, present the component plan to the user:

```
## Generated Plugin: [name]

| Component | Type | Name | Purpose |
|-----------|------|------|--------|
| Skill | Domain | [name] | [purpose] |
| Skill | Telemetry | plugin-telemetry | Usage logging and violation tracking |
| Command | Action | /[name] | [purpose] |
| Agent | Workflow | [name] | [purpose] |

Total files: [count]
```

Ask: "Does this look right? Any components to add, remove, or change before I generate the files?"

### Step 6: Write Files, Validate, and Package

1. **Write all files** using the Write tool with absolute paths. plugin.json goes at `.claude-plugin/plugin.json` inside the plugin directory.

2. **Run the plugin.json validation script** (shown in Step 4 above) immediately after writing it. Fix and rewrite if it fails. Do not skip this step.

3. **Verify all required files exist:**
   ```bash
   ls .claude-plugin/plugin.json README.md skills/plugin-telemetry/SKILL.md
   ```
   If any file is missing, write it now.

4. **Verify Claude OS Identity block exists in README:**
   ```bash
   grep -q "## Claude OS Identity" README.md && echo "OK — Claude OS Identity block found" || echo "FAIL: missing Claude OS Identity block"
   ```
   If missing, add it now using the template from Step 4b.

5. **Verify no duplicate component names** across skills, commands, and agents:
   ```bash
   python3 -c "
   import os, sys
   skills = [d for d in os.listdir('skills') if os.path.isdir(f'skills/{d}')] if os.path.isdir('skills') else []
   commands = [f.replace('.md','') for f in os.listdir('commands') if f.endswith('.md')] if os.path.isdir('commands') else []
   agents = [f.replace('.md','') for f in os.listdir('agents') if f.endswith('.md')] if os.path.isdir('agents') else []
   all_names = skills + commands + agents
   dupes = [n for n in set(all_names) if all_names.count(n) > 1]
   if dupes:
       print('FAIL: duplicate component names found:', dupes)
       print('  Skills:', skills)
       print('  Commands:', commands)
       print('  Agents:', agents)
       sys.exit(1)
   print('OK — all component names are unique across skills, commands, and agents')
   print(f'  Skills ({len(skills)}):', skills)
   print(f'  Commands ({len(commands)}):', commands)
   print(f'  Agents ({len(agents)}):', agents)
   "
   ```
   If this fails, rename the conflicting component (see Step 2a rules) and rewrite the affected files.

6. **Verify agent files** (if the plugin has agents):
   - **Frontmatter structure:** Confirm the block between `---` delimiters contains only `name`, `description`, `model`, `color`, `tools`. If `<example>` tags appear inside the frontmatter, move them to after the closing `---`.
   - **Unquoted colons in descriptions:** If any agent's `description` value contains `: ` (colon followed by space) on a single line, convert it to `description: >` block scalar format.
   - **Valid keys in plugin.json:** Confirm no `displayName` or other non-standard keys exist.

7. **Package the plugin.** Run this from INSIDE the plugin directory (not its parent):
   ```bash
   cd /absolute/path/to/[plugin-name] && \
   zip -r /tmp/[plugin-name].plugin . -x "*.DS_Store" -x ".git/*" && \
   echo "Packaged successfully"
   ```
   **Critical:** The `cd` must go INTO the plugin directory (e.g., `/sessions/.../outputs/my-plugin`), not the parent. If you zip from the parent, the zip will have a subfolder wrapper and the validator will not find `.claude-plugin/plugin.json`.

8. **Verify the zip contains the right structure:**
   ```bash
   unzip -l /tmp/[plugin-name].plugin | grep -E "plugin\.json|SKILL\.md"
   ```
   The output must show `.claude-plugin/plugin.json` at the root (not inside a subdirectory). If you see `my-plugin/.claude-plugin/plugin.json`, the zip is wrong — you ran it from the parent directory. Fix the cd path and repackage.

9. **Copy to outputs:**
   ```bash
   cp /tmp/[plugin-name].plugin /path/to/outputs/[plugin-name].plugin
   ```

10. Present the `.plugin` file to the user.

11. Ask: "Want me to add this to the Olytic marketplace?"
    - If yes, invoke the marketplace-management skill
